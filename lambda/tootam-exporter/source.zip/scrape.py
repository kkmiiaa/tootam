# encoding: utf-8

import gspread
from google.oauth2.service_account import Credentials

class ScrapeSite:
    def __init__(
        self,
        site_name = None,
        enabled = None,
        category = None,
        category_color = None,
        item_count = None,
        login_url = None, 
        login_id_css = None,
        login_pass_css = None,
        submit_button_css = None,
        login_id = None,
        login_pass = None,
        site_url = None,
        list_css = None,
        item_css = None,
        url_css = None,
        title_css = None
    ):
        self.site_name = site_name
        self.enabled = enabled
        self.category = category
        self.category_color = category_color
        self.item_count = item_count
        
        self.login_url = login_url
        self.login_id_css = login_id_css
        self.login_pass_css = login_pass_css
        self.submit_button_css = submit_button_css
        self.login_id = login_id
        self.login_pass = login_pass

        self.site_url = site_url
        self.list_css = list_css
        self.item_css = item_css
        self.url_css = url_css
        self.title_css = title_css

class Target:
    def __init__(self, credential_path, spreadsheet_key):
        credentials = Credentials.from_service_account_file(credential_path, scopes=['https://www.googleapis.com/auth/spreadsheets'])
        gc = gspread.authorize(credentials)
        self.spreadsheet = gc.open_by_key(spreadsheet_key)

        self.sites = []
        for row in self.spreadsheet.sheet1.get_all_values()[1:]:
            site = ScrapeSite(
                site_name = row[0] if len(row[0]) > 0 else None,
                enabled = True if row[1] == "TRUE" else False,
                category = row[2] if len(row[2]) > 0 else None,
                category_color = row[3] if len(row[3]) > 0 else None,
                item_count = int(row[4]) if len(row[4]) > 0 else 10,
                login_url = row[5] if len(row[5]) > 0 else None,
                login_id_css = row[6] if len(row[6]) > 0 else None,
                login_pass_css = row[7] if len(row[7]) > 0 else None,
                submit_button_css = row[8] if len(row[8]) > 0 else None,
                login_id = row[9] if len(row[9]) > 0 else None,
                login_pass = row[10] if len(row[10]) > 0 else None,
                site_url = row[11] if len(row[11]) > 0 else None,
                list_css = row[12] if len(row[12]) > 0 else None,
                item_css = row[13] if len(row[13]) > 0 else None,
                url_css = row[14] if len(row[14]) > 0 else None,
                title_css = row[15] if len(row[15]) > 0 else None
            )
            self.sites.append(site)

class ScrapedItem:
    def __init__(self, title, url):
        self.title = title
        self.url = url
        
    def __str__(self):
        return f"ScrapedItem<title: {self.title}, url: {self.url}>"

    def __repr__(self):
        return f"ScrapedItem<title: {self.title}, url: {self.url}>"